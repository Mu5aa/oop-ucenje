

public class DiceTask {


    public static void main(String[] args) {
        MainDice dice = new MainDice(6);

        int i=0;
        while(i<10){
            System.out.println( dice.roll());
            i++;
        }   
    }

}
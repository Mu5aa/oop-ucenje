

import java.util.Random;

public class MainDice {
    private Random random;
    private int numberOfSides;

    public MainDice(int numberOfSides){
        this.numberOfSides = numberOfSides;
        random = new Random();

    }

    public int roll() {
        Random rand = new Random();
        int domena = rand.nextInt(numberOfSides);
        return domena;
    }
}
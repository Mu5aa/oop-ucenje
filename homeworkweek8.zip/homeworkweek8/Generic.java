package homeworkweek8;

public class Generic<value> {

    
    

  private value data;


public Generic(value data) {
    this.data = data;
  }

  
  public value getData() {
    
    return this.data;
    }
   

    public static void main(String[] args) {
        Generic<Integer> broj = new Generic(10);
    System.out.println("Integer value:  " + broj.getData());

    Generic<String> rijec = new Generic("Hello world");
    System.out.println("String value:  " + rijec.getData());
    }
    }

    


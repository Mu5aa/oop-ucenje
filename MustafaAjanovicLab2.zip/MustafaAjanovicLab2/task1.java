import java.util.Scanner;

public class task1 {
public static void main(String[] args){
        Scanner reader = new Scanner(System.in);
    
        String secret= "secret";
        
        while(true){
            System.out.print("Type the password ");
    
            String password = reader.nextLine();
    
            if (password.equals("secret")){
                System.out.print("You are right ");
                break;
            }
        }
        System.out.print(" jryy qbar");
    }
    
    
}

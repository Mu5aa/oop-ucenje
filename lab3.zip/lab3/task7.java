package lab3;
import java.util.*;


public class task7 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add("Hallo");
        list.add("Moi");
        list.add("cao");
        list.add("badger badger badger badger");
        ArrayList<Integer> lengths = lengths(list);

        System.out.println("The length of the strings: " + lengths);

        
    }

    public static ArrayList<Integer> lengths(ArrayList<String> list){
        ArrayList<Integer> lengths = new ArrayList<Integer>();
        for (String strings : list){
            lengths.add(strings.length());
        }
        return lengths;
    }
}
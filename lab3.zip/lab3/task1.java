package lab3;

public class task1 {
    public static void main(String[] args) {
        double answer=average(4,3,6,1);
        System.out.println("average: " + answer);        
    }


public static double average(int n1, int n2, int n3, int n4) {
        int sum=n1+n2+n3+n4;
        return (sum/ (double) 4);
    
}
}

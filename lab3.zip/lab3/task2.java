package lab3;
import java.util.*;

public class task2 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter your name: ");    
        String name = reader.nextLine();
        int count=0;
        for(int i=0; i<name.length(); i++){
            if(name.charAt(i) != ' ')    
            count++;
        } 
        System.out.println("Number of chars : " + count);
    }
    
}

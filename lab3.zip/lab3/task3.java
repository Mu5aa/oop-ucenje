package lab3;

import java.util.*;

public class task3 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter your name: ");    
        String name = reader.nextLine();
        for(int i=0; i<=name.length()-1; i++){
            System.out.println((i+1) + " character " + name.charAt(i));
        }
        
    }
}

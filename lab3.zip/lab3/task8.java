package lab3;
import java.util.*;

public class task8 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Type a text:");
        String word = reader.nextLine();
        String reverse="";

        for(int i = (word.length()-1); i>=0; i--){
            reverse+=word.charAt(i);    
        }
        if(reverse.equals(word)){
            System.out.println("It is a palindrom.");
        } else {
            System.out.println("It is NOT a palindrom");
        }
    }
}

package lab3;
import java.util.*;


public class task5 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter 1st word: ");    
        String word1 = reader.nextLine();
        System.out.println("Enter 2nd word: ");    
        String word2 = reader.nextLine();
        
        if(word1.indexOf(word2)==-1){
            System.out.println("Does not contain");
        } else{
            System.out.println("The word " + word1 + " is found in word " + word2);
        }
        
    }
}

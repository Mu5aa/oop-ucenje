package tasksweek7;

public class maincounter {
    public static void main(String[] args) {
        
        Counteer brojac=new Counteer();
        brojac.reset();
        brojac.displaycounter();
        
    }
    
}

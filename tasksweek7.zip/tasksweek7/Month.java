package tasksweek7;

public class Month {
    
int month=0;
    public Month(int monthInt){

        month=monthInt;
     
    }
    
   
    
    



    public void checkletter(char first,char second,char third){
        if ((first == 'j') && (second == 'a') && (third == 'n')) 
        month = 1; 
       if ((first == 'f') && (second == 'e') && (third == 'b')) 
        month = 2; 
       if ((first == 'm') && (second == 'a') && (third == 'r')) 
        month = 3; 
       if ((first == 'a') && (second == 'p') && (third == 'r')) 
        month = 4; 
       if ((first == 'm') && (second == 'a') && (third == 'y')) 
        month = 5; 
       if ((first == 'j') && (second == 'u') && (third == 'n')) 
        month = 6; 
       if ((first == 'j') && (second == 'u') && (third == 'l')) 
        month = 7; 
       if ((first == 'a') && (second == 'u') && (third == 'g')) 
        month = 8; 
       if ((first == 's') && (second == 'e') && (third == 'p')) 
        month = 9; 
       if ((first == 'o') && (second == 'c') && (third == 't')) 
        month = 10; 
       if ((first == 'n') && (second == 'o') && (third == 'v')) 
        month = 11; 
       if ((first == 'd') && (second == 'e') && (third == 'c')) 
        month = 12; 

        
        if (month >= 1 && month <= 12) {
            System.out.println("Month: "+ month );
        }
       
        else{ 
      
         System.out.println("month is not valid");
       } 
       
    }
   
    
    

public void outputmonths(){
    switch (month) {
        case 1:
            System.out.println("January");
            break;
        case 2:
            System.out.println("February");
            break;
        case 3:
            System.out.println("March");
            break;
        case 4:
            System.out.println("April");
            break;
        case 5:
            System.out.println("May");
            break;
        case 6:
            System.out.println("June");
            break;
        case 7:
            System.out.println("July");
            break;
        case 8:
            System.out.println("August");
            break;
        case 9:
            System.out.println("September");
            break;
        case 10:
            System.out.println("October");
            break;
        case 11:
            System.out.println("November");
            break;
        case 12:
            System.out.println("December");
            break;
            default:
            System.out.println("not valid month");
        
    }
}
}


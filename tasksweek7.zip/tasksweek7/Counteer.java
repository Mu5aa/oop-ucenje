package tasksweek7;

public class Counteer {
    int counter;
    int  Max_count = 9999;
    public Counteer(){
        
        
     
    }

    

    public void reset(){
        counter=0;

    }

    public void incr1(){
        counter+=1;
    }
    public void incr10(){
        counter+=10;
        

    } 
    public void incr100(){
        counter+=100;

    }
    public void incr1000(){
        counter+=1000;
       
        
    }
    public Boolean overflow()
    {
        if(counter > Max_count)
        {
            return true;
        }
        return false;

    }

    public void displaycounter(){
        System.out.println(counter);
    }
   
    
    
    
}
package tasksweek7;



public class mainmonth {
    public static void main(String[] args) {

        Month mjesec= new Month(98);
        
        mjesec.outputmonths();
        mjesec.checkletter('f','e','b');
        
    }
    
}
